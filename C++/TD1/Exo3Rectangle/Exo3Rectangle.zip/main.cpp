#include"rectangle.h"
int main(){
    rectangle rect(7,7),rect1(7,7),rect2(10,20);
    if(rect==rect1){
      cout<<"Les deux rectangle sont egals\n";
    }
    else
    cout<<"Les deux rectangle sont differents\n";
    rect.affiche();
    rect1.sethauteur(6);
    rect1.setlargeur(14); 
    rect1.affiche();
    cout<<"la surface du rectangle est:\t"<<rect.surface();
    cout<<"\nle perimetre du rectangle est:\t"<<rect.perimetre();
    if(rect.compare(rect1))
      cout<<"\nles deux rectangle sont egals\n";
    else 
    cout<<"\nLes deux rectangles sont differents\n"; 
    cout<<"La sur-definition de l'operateur<<\n"<<rect2; 
  return 0;
}