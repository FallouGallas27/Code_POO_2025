#include<iostream>
using namespace std;
class rectangle
{
private:
   unsigned int m_long;
   unsigned int m_larg;
public:
    rectangle( unsigned int longueur =0,unsigned int largeur=0);
    ~rectangle();
    unsigned int getlargeur()const;
    unsigned int gethauteur()const;
    unsigned int perimetre();
    unsigned int surface();
    void setlargeur(unsigned int);
    void sethauteur(unsigned int);
    bool compare(const rectangle&);
    bool operator==(const rectangle&);
    friend ostream & operator<<(ostream & sortie,const rectangle&);
    void affiche();
};

